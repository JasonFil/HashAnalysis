package probing;

public interface ProbePolicy {
	public int next(int hashValue, int index);
}
